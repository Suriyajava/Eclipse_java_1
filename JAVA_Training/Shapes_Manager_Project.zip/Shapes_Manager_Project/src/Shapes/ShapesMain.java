package Shapes;

public class ShapesMain {
	public static void main(String[] args) {
		Menu m=new Menu();
		m.displayMainMenu();
		m=null;
		System.out.println("Thanks for your choice. Program ends Here!");
	} 

}
